#!/bin/bash

#argumentosDeEjecución
argExe1=$1
argDebug=$2

alto=15
ancho=15


#Colores:
blue='\e[104m'
red='\e[41m'
green='\e[102m'
white='\e[107m'
magenta='\e[45m'
cyan='\e[46m'

default='\e[49m'

verde="$green $default"
rojo="$red $default"
azul="$blue $default"
blanco="$white $default"
magentaB="$magenta $default"
cyanB="$cyan $default"
loopsPrint=0

mkdir ./cfg
echo "false" > ./cfg/status

main(){

	
	argumentosEjecución
	f_clear
	inicio
	cabecera
	gameLoop&
	loop_PID=$!

	userInput

}




f_clear(){


	if [[ $atributoClear == false ]]; then
		atributoClear=true
	else
		clear
	fi


	echo "$0 -h para más información"
	echo
	echo


}

cabecera(){
	echo "

	███████╗███╗   ██╗ █████╗ ██╗  ██╗███████╗      ██████╗  █████╗ ███████╗██╗  ██╗
	██╔════╝████╗  ██║██╔══██╗██║ ██╔╝██╔════╝      ██╔══██╗██╔══██╗██╔════╝██║  ██║
	███████╗██╔██╗ ██║███████║█████╔╝ █████╗  █████╗██████╔╝███████║███████╗███████║
	╚════██║██║╚██╗██║██╔══██║██╔═██╗ ██╔══╝  ╚════╝██╔══██╗██╔══██║╚════██║██╔══██║
	███████║██║ ╚████║██║  ██║██║  ██╗███████╗      ██████╔╝██║  ██║███████║██║  ██║
	╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
	                                                                                
	     _                        ___        _        ___                      
	  _ | | ___  _ _  __ _  ___  | _ \ _  _ (_) ___  / __| ___  _ __   ___  ___
	 | || |/ _ \| '_|/ _  |/ -_) |   /| || || ||_ / | (_ |/ _ \| '  \ / -_)|_ /
	  \__/ \___/|_|  \__, |\___| |_|_\ \_,_||_|/__|  \___|\___/|_|_|_|\___|/__|
	                 |___/                                                     
	                                                                   



	"
	echo "W) Arriba"
	echo "S) Abajo"
	echo "A) Izquierda"
	echo "D) Derecha"
	echo
	echo "P) Pausa"
	echo "X) Salir"

}

inicio(){
	declare -Ag grid
	#atributos y configuración de inicio
	SnakePosInicial
	gridBorders
	gridManzana

}

gameLoop(){

for ((;;)); do
	sleep 0.17
	#statements
	empezarJuego=$(cat ./cfg/status)

	until [[ $empezarJuego == true ]]; do
		empezarJuego=$(cat ./cfg/status)
	done

	clear

		

	
	gridSnake
	moverSerpiente
	gridPrint
done
}

moverSerpiente(){


	
		
	echo -n "Moviendo cabeza: "
	mov=$(cat ./cfg/input)
	case $mov in
		U)
		if [[ $cabezaZ != D ]]; then
			((cabezaY--))
			cabezaZ=$mov
			echo -n "T "
		fi
		
		;;
		D)
		if [[ $cabezaZ != U ]]; then
			((cabezaY++))
			cabezaZ=$mov
			echo -n "T "
		fi
		;;
		L)
		if [[ $cabezaZ != R ]]; then
			((cabezaX--))
			cabezaZ=$mov
			echo -n "T "
		fi
		;;
		R)
		if [[ $cabezaZ != L ]]; then
			((cabezaX++))
			cabezaZ=$mov
			echo -n "T "
		fi
		;;
	esac
	
	echo $cabezaX $cabezaY $mov $cabezaZ

}

gridPrint(){
	((loopsPrint++))
	for ((i=0;i<=bordeAncho;i++)); do
		for((j=0; j<=bordeAlto;j++));do
			echo -ne "${grid[$i,$j]}"
				#**************DEBUG**************					
				if [[ $debugPrint1 == true ]]; then

				echo -ne $i,$j 

				fi
				#**************DEBUG**************	


		done
			echo
	done
	printf "Loops: %d \n" $loopsPrint
}

gridBorders(){

	bordeAlto=$((alto+1))
	bordeAncho=$((ancho+1))
	flagLaterales=1
	colorM=1
	#rellenamos el grid
	
	for((i=0;i<=bordeAncho;i++)); do
		
		colorMarco 1 #Con 1, el marco (entre esquinas) es Magenta, 2 cyan

		for ((j=0;j<=bordeAlto;j++)); do
			colorMarco 

			#Si estams en el borde superioor (y=0) o inferior (y=bordeAlto, es decir, por defecto y=15)
			if ((i==0 || i== bordeAlto))
			then
				#Si son las esquinas; then:
				if ((j==0 || j==bordeAncho))
				then
					grid[$i,$j]=$blanco$blanco

				#Si no son esquinas, que se rellene con el marco
				else
					grid[$i,$j]="$marco$marco"
				fi

				#Si son los laterales/marcos verticales: 
			elif ((j==0 || j==$bordeAncho))
				then
					colorMarco 3 0
				grid[$i,$j]="$marco$marco"
			else
				grid[$i,$j]="  "
			fi

		done #FinLoop j 
	done #FinLoop i

}

colorMarco(){
#	┌─┐┬    ┌─┐┬ ┬┌┐┌┌─┐┬┌─┐┌┐┌┌─┐
#	└─┐│    ├┤ │ │││││  ││ ││││├─┤
#	└─┘┴    └  └─┘┘└┘└─┘┴└─┘┘└┘┴ ┴
#	                              
#	                              
#	                              
#	┌┐┌┌─┐                        
#	││││ │                        
#	┘└┘└─┘                        
#	┬  ┌─┐                        
#	│  │ │                        
#	┴─┘└─┘                        
#	┌┬┐┌─┐┌─┐ ┬ ┬┌─┐┌─┐           
#	 │ │ ││─┼┐│ │├┤ └─┐           
#	 ┴ └─┘└─┘└└─┘└─┘└─┘  


	#Esta función permite alternar el color del marco sin ensuciar mucho el código
	#No se puede reutilzar con una variable distinta a \$marco
	#Con el parámetro 1 o 2 (como $1). Se puede forzar un color del que partir
	#Si $1 es 3, se ejecuta un subrutina especial para los laterales, ya que si se alterna de la misma manera por defecto
	#cada borde será de un mismo color, y no tendrá forma de "tablero de ajedrez"
	

	
	if [[ $1 -eq 1 ]]; then
		local colorM=1
	elif [[ $1 -eq 2 ]]; then
		local colorM=2
	elif [[ $1 -eq 3 ]]; then
		local laterales=true
	fi	

	
	if [[ $2 -eq 1 ]]; then
	
		marco=$magentaB
	fi

	if [[ $laterales != true ]]; then
		#statements
		
		colorM=$((colorM+1))

		if (($((colorM%2))==0))
		then
			marco=$magentaB
		else
			marco=$cyanB
		fi
	else
		if ((flagLaterales==17)) #por alguna razón, igualar a 17 permite que se genere el marco cuando es 15*15
			#la única forma que se me ocurre para hacer los marcos distintos, es rellenar todo el grid, y luego vaciar el centro
		then

			flagLaterales=1

			if [[ $marco == $cyanB ]]; then
				marco=$magentaB
			else
				marco=$cyanB
			fi
		else

			flagLaterales=$((flagLaterales+1))

		fi


	fi







	#local maxBucle=2
	#if [[ $1 -eq 1 ]]; then
	#	colorM=1
	#elif [[ $1 -eq 2 ]]; then
	#	colorM=2
	#fi


	#	if (( colorM==1)); then
	#		marco=$magentaB
	#		colorM=2
	#	elif ((colorM==2));then
	#		marco=$cyanB
  

#			colorM=1
#		fi

#	if (($1==3));
#	then
	echo -n
}

SnakePosInicial(){

	#define la posición inicial de la serpiente
	#crearemos 3 varaibles. eje x, eje y, y dirección a la que mira

	cabezaX=5
	cabezaY=8
	cabezaZ=R #U,D,L,R Up, Down, left, right

	cuerpoX=$cabezaX
	cuerpoY=$cabezaY
	snakeLongitudInicial=4
	snakeLongitud=$snakeLongitudInicial
}

gridSnake(){

	#añade a la serpiente al array
	grid[$cabezaY,$cabezaX]=$cabezaSerpiente
	cuerpoX=$cabezaX
	cuerpoY=$cabezaY
	


	for ((i=1;i<snakeLongitud;i++)); do
		case $cabezaZ in
			U)
			((cuerpoY++))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			D)
			((cuerpoY--))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			L)
			((cuerpoX++))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			R)
			((cuerpoX--))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor

				#**************DEBUG**************					
				if [[ $debugGridSnake == true ]]; then

				echo -n $cuerpoX,$cuerpoY 
				echo
				fi
				#**************DEBUG**************				
			;;
		esac
		snakeLongitud=2
	done
	colaX=$cuerpoX
	colaY=$cuerpoY
	grid[$colaY,$colaX]="  "
}



gridManzana(){


	hayManzana=false

	until [[ $hayManzana == true ]]; do
		manzanaX=$(( $RANDOM % $alto + 1 ))
		manzanaY=$(( $RANDOM % $ancho + 1 ))


		cuadranteLeido=${grid[$manzanaX,$manzanaY]}
		#comprbamos que no hay un color esa coordenada, significará que está vacía y puede aparecer
		if [[ ${cuadranteLeido:0:1} == '\' ]]; then
			hayManzana=false
		else
			hayManzana=true
		fi

	done

	grid[$manzanaX,$manzanaY]=$rojo$rojo
}
pausar(){

	echo Pulse [Enter] para continuar
	echo "false" > ./cfg/status
	read hola
	echo "true" > ./cfg/status
}


userInput(){

	for ((;;)); do
	read -s -n 1 entradaUsuario
		
	echo "false" > ./cfg/status

	case $entradaUsuario in
		w|W) 
		mov=U
		echo "true" > ./cfg/status
		;;

		a|A) 
		mov=L
		echo "true" > ./cfg/status
		;;

		s|S)
		mov=D
		echo "true" > ./cfg/status
		;; 

		d|D)
		mov=R
		echo "true" > ./cfg/status
		;;

		x|X)
		echo -e "Saliendo..."

		kill $loop_PID
		sleep 0.5
		exit 0
		
		;;
		p|P)
		pausar
		;;
	esac
	
	echo "$mov" > ./cfg/input
	export mov=$mov
	sleep 
done


}

argumentosEjecución(){


	if [[ $(echo $argExe1 | cut -c 1 ) == "-" ]]
	then

	hayParametro=true

	numeroDeParametrosIntroducidos=$(( $(echo $argExe1 | wc -c)-1))	#restamos 1 unidad ya que cuenta el \n como un caracter (creo)

	declare -ag arrayParametrosIntroducidos

	for ((i=1;i<=numeroDeParametrosIntroducidos;i++)); do

		arrayParametrosIntroducidos[$i]=$(echo $argExe1 | cut -c $i)



	done
fi



if [[ $hayParametro == true ]]
	then

		for ((i=2; i<= numeroDeParametrosIntroducidos; i++)); do

			case ${arrayParametrosIntroducidos[i]} in 
				d)
					echo "Modo debug: Activado"
					debug=true
					argDebug
				;;
				h) 
					help
				;;
				c)
					atributoClear=false
				;;
				*)
					echo "El parámetro introducido \"${arrayParametrosIntroducidos[i]}\" no es válido"
					echo "Utilice -h para visualizar otros parámetros"
				;;
				
			esac
		done
fi

}

help(){

	echo "Bienvenido a la función \"Información\""

	echo "-h: Ayuda"
	echo "-d: Debug General"
	echo "introduzca un segundo parámetro (equivalente a \$2) para introducir debugs indiviuales"
	echo "Si introduce h (sin -) como segundo parámetro, obtendrá la lista general"
	echo "-c: Clear; desactiva el primer clear"



	echo
	echo "Saliendo..."
	echo 
	exit 0
}

argDebug(){


	
	numeroDeParametrosIntroducidosDebug=$(( $(echo $argDebug | wc -c)-1))	#restamos 1 unidad ya que cuenta el \n como un caracter (creo)

if ((numeroDeParametrosIntroducidosDebug >=1))
then
	declare -ag arrayParametrosIntroducidosDebug

	for ((i=1;i<=numeroDeParametrosIntroducidosDebug;i++)); do

		arrayParametrosIntroducidosDebug[$i]=$(echo $argDebug| cut -c $i)

	done

		for ((i=1; i<= numeroDeParametrosIntroducidosDebug; i++)); do

			case ${arrayParametrosIntroducidosDebug[i]} in 
				-)
					echo No es necisario introducir \"-\" leñe
					echo
				;;
				d)
					echo "Modo debug: Activado"
					debug=true
					
				;;
				p)
					echo "Modo Debug Print1: Activado"
					debugPrint1=true
				;;
				b) 	echo "Modo Debug gridSnake: Activado"
					debugGridSnake=true
				;;
				h) 
					
					echo Lista de parámetros:
					


					exit 0
				;;
				*)
					echo "El parámetro introducido \"${arrayParametrosIntroducidos[i]}\" no es válido"
					echo "Utilice \"-d h\" para visualizar otros parámetros"
				;;

				
			esac
		done
fi
}

velocidadJuego=0.5
cabezaSerpiente=$verde$verde
cuerpoSerpienteColor=$rojo$rojo


main
#!/bin/bash

#argumentosDeEjecución
argExe1=$1
argDebug=$2

alto=15
ancho=15


#Colores:
blue='\e[104m'
red='\e[41m'
green='\e[102m'
white='\e[107m'
magenta='\e[45m'
cyan='\e[46m'

default='\e[49m'

verde="$green $default"
rojo="$red $default"
azul="$blue $default"
blanco="$white $default"
magentaB="$magenta $default"
cyanB="$cyan $default"
main(){

	
	argumentosEjecución
	f_clear
	inicio
	gameLoop


}

f_clear(){


	if [[ $atributoClear == false ]]; then
		atributoClear=true
	else
		clear
	fi


	echo "$0 -h para más información"
	echo
	echo


}

inicio(){

	#atributos y configuración de inicio
	SnakePosInicial


}

gameLoop(){

	declare -Ag grid

	gridBorders
	gridSnake
	gridManzana
	gridPrint

}

gridPrint(){

	for ((i=0;i<=bordeAncho;i++)); do
		for((j=0; j<=bordeAlto;j++));do
			echo -ne "${grid[$i,$j]}"
				#**************DEBUG**************					
				if [[ $debugPrint1 == true ]]; then

				echo -ne $i,$j 

				fi
				#**************DEBUG**************	


		done
			printf "\n"
	done

}

gridBorders(){

	bordeAlto=$((alto+1))
	bordeAncho=$((ancho+1))

	#rellenamos el grid
	
	for((i=0;i<=bordeAncho;i++)); do
		
		colorMarco 2 #Con 1, el marco (entre esquinas) es Magenta, 2 cyan

		for ((j=0;j<=bordeAlto;j++)); do
			colorMarco

			#Si estams en el borde superioor (y=0) o inferior (y=bordeAlto, es decir, por defecto y=15)
			if ((i==0 || i== bordeAlto))
			then
				#Si son las esquinas; then:
				if ((j==0 || j==bordeAncho))
				then
					grid[$i,$j]=$blanco$blanco

				#Si no son esquinas, que se rellene con el marco
				else
					grid[$i,$j]="$marco$marco"
				fi

				#Si son los laterales/marcos verticales: 
			elif ((j==0 || j==$bordeAncho))
				then
					colorMarco 3
				grid[$i,$j]="$marco$marco"
			else
				grid[$i,$j]="  "
			fi

		done #FinLoop j 
	done #FinLoop i

}

colorMarco(){
	#Esta función permite alternar el color del marco sin ensuciar mucho el código
	#No se puede reutilzar con una variable distinta a \$marco
	#Con el parámetro 1 o 2 (como $1). Se puede forzar un color del que partir
	#Si $1 es 3, se doble alterna el color, ya que es necesario porque los laterales se quedarían de un color cada (se necesitaría un triple alternar)
	
	#local maxBucle=2
	#if [[ $1 -eq 1 ]]; then
	#	colorM=1
	#elif [[ $1 -eq 2 ]]; then
	#	colorM=2
	#fi


	#	if (( colorM==1)); then
	#		marco=$magentaB
	#		colorM=2
	#	elif ((colorM==2));then
	#		marco=$cyanB
#			colorM=1
#		fi

#	if (($1==3));
#	then
	echo -n
}

SnakePosInicial(){

	#define la posición inicial de la serpiente
	#crearemos 3 varaibles. eje x, eje y, y dirección a la que mira

	cabezaX=5
	cabezaY=8
	cabezaZ=R #U,D,L,R Up, Down, left, right

	cuerpoX=$cabezaX
	cuerpoY=$cabezaY
	snakeLongitudInicial=4
	snakeLongitud=$snakeLongitudInicial
}

gridSnake(){

	#añade a la serpiente al array
	grid[$cuerpoY,$cuerpoX]=$verde$verde
	
	cuerpoSerpienteColor=$rojo$azul
	for ((i=1;i<snakeLongitud;i++)); do
		case $cabezaZ in
			U)
			$((cuerpoY--))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			D)
			$((cuerpoY++))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			L)
			$((cuerpoX++))
			grid[$cuerpoY,$cuerpoX]=$cuerpoSerpienteColor
			;;
			R)
			((cuerpoX--))
			grid[$cuerpoY,$cuerpoX]=$rojo$azul

				#**************DEBUG**************					
				if [[ $debugGridSnake == true ]]; then

				echo -n $cuerpoX,$cuerpoY 
				echo
				fi
				#**************DEBUG**************				
			;;
		esac

	done

}

gridManzana(){


	hayManzana=false

	until [[ $hayManzana == true ]]; do
		manzanaX=$(( $RANDOM % $alto + 1 ))
		manzanaY=$(( $RANDOM % $ancho + 1 ))


		cuadranteLeido=${grid[$manzanaX,$manzanaY]}
		#comprbamos que no hay un color esa coordenada, significará que está vacía y puede aparecer
		if [[ ${cuadranteLeido:0:1} == '\' ]]; then
			hayManzana=false
		else
			hayManzana=true
		fi

	done

	grid[$manzanaX,$manzanaY]=$rojo$rojo
}

userInput(){

	read entradaUsuario
	sleep 0.2


}

argumentosEjecución(){


	if [[ $(echo $argExe1 | cut -c 1 ) == "-" ]]
	then

	hayParametro=true

	numeroDeParametrosIntroducidos=$(( $(echo $argExe1 | wc -c)-1))	#restamos 1 unidad ya que cuenta el \n como un caracter (creo)

	declare -ag arrayParametrosIntroducidos

	for ((i=1;i<=numeroDeParametrosIntroducidos;i++)); do

		arrayParametrosIntroducidos[$i]=$(echo $argExe1 | cut -c $i)



	done
fi



if [[ $hayParametro == true ]]
	then

		for ((i=2; i<= numeroDeParametrosIntroducidos; i++)); do

			case ${arrayParametrosIntroducidos[i]} in 
				d)
					echo "Modo debug: Activado"
					debug=true
					argDebug
				;;
				h) 
					help
				;;
				c)
					atributoClear=false
				;;
				*)
					echo "El parámetro introducido \"${arrayParametrosIntroducidos[i]}\" no es válido"
					echo "Utilice -h para visualizar otros parámetros"
				;;
				
			esac
		done
fi

}

help(){

	echo "Bienvenido a la función \"Información\""

	echo "-h: Ayuda"
	echo "-d: Debug General"
	echo "introduzca un segundo parámetro (equivalente a \$2) para introducir debugs indiviuales"
	echo "Si introduce h (sin -) como segundo parámetro, obtendrá la lista general"
	echo "-c: Clear; desactiva el primer clear"



	echo
	echo "Saliendo..."
	echo 
	exit 0
}

argDebug(){


	
	numeroDeParametrosIntroducidosDebug=$(( $(echo $argDebug | wc -c)-1))	#restamos 1 unidad ya que cuenta el \n como un caracter (creo)

if ((numeroDeParametrosIntroducidosDebug >=1))
then
	declare -ag arrayParametrosIntroducidosDebug

	for ((i=1;i<=numeroDeParametrosIntroducidosDebug;i++)); do

		arrayParametrosIntroducidosDebug[$i]=$(echo $argDebug| cut -c $i)

	done

		for ((i=1; i<= numeroDeParametrosIntroducidosDebug; i++)); do

			case ${arrayParametrosIntroducidosDebug[i]} in 
				-)
					echo No es necisario introducir \"-\" leñe
					echo
				;;
				d)
					echo "Modo debug: Activado"
					debug=true
					
				;;
				p)
					echo "Modo Debug Print1: Activado"
					debugPrint1=true
				;;
				b) 	echo "Modo Debug gridSnake: Activado"
					debugGridSnake=true
				;;
				h) 
					
					echo Lista de parámetros:
					


					exit 0
				;;
				*)
					echo "El parámetro introducido \"${arrayParametrosIntroducidos[i]}\" no es válido"
					echo "Utilice \"-d h\" para visualizar otros parámetros"
				;;
				
			esac
		done
fi
}
main